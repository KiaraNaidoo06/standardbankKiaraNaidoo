import requests
import shelve

POKEAPI_BASE_URL = "https://pokeapi.co/api/v2"          #We refer to this URL for the PokeAPI

#Fetch Pokémon Data [from the API or cache]
def Get_PokemonInfo(PokemonName, cache):
    if PokemonName in cache:                            #Check if the data is cached
        return cache[PokemonName]
    
    url = f"{POKEAPI_BASE_URL}/pokemon/{PokemonName}"   #If not cached, we fetch from the API
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        cache[PokemonName] = data                       #Cache the data
        return data
    else:
        return None

#Display Pokémon Information

def Display_PokemonInfo(PokemonInfo):
    if PokemonInfo:
        print(f"Name: {PokemonInfo['name']}")
        print("Abilities:")
        for ability in PokemonInfo['abilities']:
            print(f"  - {ability['ability']['name']}")
        print("Types:")
        for ptype in PokemonInfo['types']:
            print(f"  - {ptype['type']['name']}")
    else:
        print("Pokemon not found.")

#Filter Pokémon by Type (Didnt cache Type data - expected it to be less common than Ability)
def Filter_Type(PokemonType):
    url = f"{POKEAPI_BASE_URL}/type/{PokemonType}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        return data['pokemon']
    else:
        return None
    
#Filter Pokémon by Ability
def Filter_Ability(AbilityName, cache):
    if AbilityName in cache:                              #Check if the data is cached
        return cache[AbilityName]
    
    url = f"{POKEAPI_BASE_URL}/ability/{AbilityName}"     #If not cached, we fetch from the API
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        cache[AbilityName] = data                         #Cache the data
        return data['pokemon']
    else:
        return None

#Fetch a list of all Pokémon
def Get_AllPokemon(cache):
    if 'all_pokemon' in cache:                           #Check if the data is cached
        return cache['all_pokemon']
    
    url = f"{POKEAPI_BASE_URL}/pokemon?limit=1000"       #Limited to 1000 Pokes
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        cache['all_pokemon'] = data['results']          #Cache the data
        return data['results']
    else:
        return None

#Main loop
with shelve.open("pokemon_cache") as cache:
    while True:
        option = input("Enter '1' to fetch a Pokémon, '2' to filter by type, '3' to filter by ability, '4' to view all Pokémon, or 'exit' to quit: ").lower()
        
        if option == 'exit':
            break
        elif option == '1':
            sPokemonName = input("Enter the name of a Pokémon: ").lower()
            pokemon_info = Get_PokemonInfo(sPokemonName, cache)
            Display_PokemonInfo(pokemon_info)
        elif option == '2':
            sPokemonType = input("Enter the type of Pokémon to filter: ").lower()
            filtered_pokemon = Filter_Type(sPokemonType)
            
            if filtered_pokemon:
                print(f"Pokémon with type '{sPokemonType}':")
                for entry in filtered_pokemon:
                    print(f"  - {entry['pokemon']['name']}")
            else:
                print("No Pokémon found with the given type.")
        elif option == '3':
            sAbilityName = input("Enter the name of the ability to filter Pokémon: ").lower()
            filtered_pokemon = Filter_Ability(sAbilityName, cache)
            
            if filtered_pokemon:
                print(f"Pokémon with ability '{sAbilityName}':")
                for entry in filtered_pokemon:
                    print(f"  - {entry['pokemon']['name']}")
            else:
                print("No Pokémon found with the given ability.")
        elif option == '4':
            all_pokemon = Get_AllPokemon(cache)
            
            if all_pokemon:
                print("List of all Pokémon:")
                for entry in all_pokemon:
                    print(f"  - {entry['name']}")
            else:
                print("Failed to fetch the list of all Pokémon.")
